<template>
  <router-view></router-view>
</template>

<script setup>
// 这里可以为空
</script> 